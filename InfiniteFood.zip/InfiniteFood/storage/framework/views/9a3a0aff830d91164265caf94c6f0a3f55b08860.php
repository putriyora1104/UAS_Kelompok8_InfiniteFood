
<?php $__env->startSection('content'); ?>

<div class="row mt-5">
    <div class="col-lg-6">

    <div class="card p-3">
        <div class="card-title"><h4>Add Food Data</h4></div>
        <div class="card-body">
            <form action="<?php echo e($Food->id!=null?'/dashboard/food/update/'.$Food->id:url('/dashboard/food/store'), false); ?>" enctype="multipart/form-data" method="POST">
                <?php echo csrf_field(); ?>


                <div class="mb-3">
                    <label for="formFile" class="form-label">Food Photo</label>
                    <input class="form-control" type="file" name="food_photo" id="formFile">
                </div>


                <div class="mb-3">
                    <label for="food_name" name="food_name" class="form-label">Food Name</label>
                    <input type="text" class="form-control" name="food_name" id="food_name" placeholder="Mendoan" required <?php echo e($Food->id!=null?"value=$Food->food_name":"", false); ?> >
                </div>

                <div class="mb-3">
                    <label for="food_description" name="food_description" class="form-label">Food Description</label>
                    <textarea class="form-control" name="food_description" id="food_description" rows="3" required ><?php echo e($Food->id!=null?$Food->food_description:'', false); ?></textarea>
                </div>


                <div class="mb-3">
                    <label for="food_category" name="food_category" class="form-label">Food Description</label>
                    <select class="form-select" name="food_category" aria-label="food_category" required>
                        <?php $__currentLoopData = $foodCategory; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $fc): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($Food->id!=null && $Food->food_category == $fc['id']): ?>
                                <option value="<?php echo e($fc['id'], false); ?> " selected><?php echo e($fc['categoryName'], false); ?></option>
                                <?php continue; ?>
                            <?php endif; ?>
                            <option value="<?php echo e($fc['id'], false); ?>"><?php echo e($fc['categoryName'], false); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>

                <div class="mb-3">
                    <label for="food_price" name="food_price" class="form-label">Food Price Average</label>
                    <select class="form-select" name="food_price" aria-label="food_price">
                        <?php for($i=1;$i<=(5);$i++): ?>
                            <?php if($Food->id!=null && $Food->food_price == $i): ?>
                                <option value="<?php echo e($fc['id'], false); ?> " selected><?php echo e($i, false); ?></option>
                                <?php continue; ?>
                            <?php endif; ?>
                            <option value="<?php echo e($i, false); ?>"><?php echo e($i, false); ?></option>
                        <?php endfor; ?>
                    </select>
                </div>

                <button type="submit" class="btn btn-primary"><?php echo e($Food->id!=null?'Save':'Submit', false); ?></button>

            </form>
        </div>
    </div>
    </div>
</div>



<?php $__env->stopSection(); ?>
<?php echo $__env->make('dashboard.template.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\Laravel\InfiniteFood\resources\views/dashboard/food_create.blade.php ENDPATH**/ ?>