
<?php $__env->startSection('pageTitle',$Food['food_name']); ?>
<?php $__env->startSection('content'); ?>
<link rel="stylesheet" href="https://unpkg.com/leaflet@1.7.1/dist/leaflet.css" integrity="sha512-xodZBNTC5n17Xt2atTPuE1HxjVMSvLVW9ocqUKLsCC5CXdbqCmblAshOMAS6/keqq/sMZMZ19scR4PsZChSR7A==" crossorigin=""/>
<script src="https://unpkg.com/leaflet@1.7.1/dist/leaflet.js" integrity="sha512-XQoYMqMTK8LvdxXYG3nZ448hOEQiglfqkJs1NOQV44cWnUrBc8PkAOcXy20w0vlaXaVUearIOBhiXZ5V3ynxwA==" crossorigin=""></script>
<div class="container mt-5">
    <div class="row mt-5">
        <div class="col-lg-12">
            <img src="<?php echo e(URL::to('/'), false); ?>/uploads/<?php echo e($Food['food_photo'], false); ?>" class="img-fluid rounded img-detail-header" alt="Responsive image">
        </div>
        <div class="col-lg-12 mt-2">
            <h2><?php echo e($Food['food_name'], false); ?></h2>
        </div>

        <div class="col-lg-12 text-muted mb-2">
            <span class=""><?php echo e($Food['category']->categoryName, false); ?></span>
            <span>•</span>
            <span>
                <?php for($i=0;$i<$Food['food_price'];$i++): ?>
                                $
                <?php endfor; ?>
            </span>
        </div>

        <div class="col-lg-12">
            <span>
                <?php echo e($Food['food_description'], false); ?>

                <hr>
            </span>
        </div>

        <div class="col-lg-12">
            <h4>Lokasi Makanan</h4>
        </div>

        <div class="col-lg-12">
            <div id="map" style="height:300px"></div>

        </div>
        
    </div>
</div>
<?php 
?>
<script>

    var locationList = <?php echo json_encode($Food->locations, 15, 512) ?>;
    console.log(locationList)
    var mymap = L.map('map').setView([-7.4244176,109.2300951], 11);
      L.tileLayer('https://api.maptiler.com/maps/hybrid/{z}/{x}/{y}@2x.jpg?key=sl5nNkAdG1bPatKbI8un', {
		maxZoom: 18,
		attribution: 'Map data &copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors, ' +
			'Imagery © <a href="https://www.maptiler.com/">MapTiler</a>',
		id: 'mapbox/streets-v11',
		tileSize: 512,
		zoomOffset: -1
    }).addTo(mymap);

    

    for(i=0;i<locationList.length;i++){

        var marker = L.marker([locationList[i]['latitude'],locationList[i]['longitude']],{
            color: 'red',
            fillColor: '#104',
            fillOpacity: 0.5,
            radius: 500,
            place_name: locationList[i]['location_name']
        }).addTo(mymap).bindPopup(locationList[i]['location_name']);
    }

    

    function onClick(e) {
        console.log(this.options.place_name)
        
    }

    
</script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('template.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\Laravel\InfiniteFood\resources\views/viewFood.blade.php ENDPATH**/ ?>