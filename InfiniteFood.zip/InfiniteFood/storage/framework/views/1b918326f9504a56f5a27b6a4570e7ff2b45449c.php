
<?php $__env->startSection('pageTitle','Food Management'); ?>
<?php $__env->startSection('content'); ?>

<div class="row">
    <div class="col-lg-12 mt-5">
        <?php if(session()->has('message')): ?>
        <div class="alert alert-success alert-dismissible fade show" role="alert">
                        <strong>Berhasil!</strong> <?php echo e(session()->get('message'), false); ?>


            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
    <?php endif; ?>
        <div class="card">
            <div class="card-body">
            <a type="button" href="<?php echo e(url('/dashboard/location/create'), false); ?>" class="btn btn-primary btn-sm" style="float:right">Tambah Data</a>


                <div class="table-responsive mt-5">
                    <table class="table table-stripped table-hover mx-auto w-auto data-table">
                        <thead>
                            <tr>
                                <th>ID</th>
                                <th>Food ID</th>
                                <th>Location Name</th>
                                <th>LAT</th>
                                <th>LNG</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<script>
    $('.data-table').DataTable({
        processing:true,
        serverSide:true,
        ajax:"<?php echo e(url('/dashboard/location'), false); ?>",

        columns:[

            {
                data:"id",
                name:"id",
            },

            {
                data:"food_id",
                name:"food_id"
            },
            
            {
                data:"location_name",
                name:"location_name",
            },

            {
                data:"latitude",
                name:"latitude",
            },

            {
                data:"longitude",
                name:"longitude",
            },

            {
                data:"action",
                name:"action",
            },
        ]
    })
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('dashboard.template.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\Laravel\InfiniteFood\resources\views/dashboard/location.blade.php ENDPATH**/ ?>