
<?php $__env->startSection('content'); ?>

<div class="row mt-5">
    <div class="col-lg-6">

    <div class="card p-3">
        <div class="card-title"><h4>Add Category Data</h4></div>
        <div class="card-body">
            <form action="<?php echo e($FoodCategory->id!=null?'/dashboard/category/update/'.$FoodCategory->id:url('/dashboard/category/store'), false); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <div class="mb-3">
                    <label for="food_category" name="food_category" class="form-label">Food Category</label>
                    <input type="text" class="form-control" name="food_category" id="food_category" placeholder="Mendoan" required <?php echo e($FoodCategory->id!=null?"value=$FoodCategory->categoryName":"", false); ?> >
                </div>
                <button type="submit" class="btn btn-primary"><?php echo e($FoodCategory->id!=null?'Save':'Submit', false); ?></button>

            </form>
        </div>
    </div>
    </div>
</div>





<?php $__env->stopSection(); ?>
<?php echo $__env->make('dashboard.template.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\Laravel\InfiniteFood\resources\views/dashboard/category_create.blade.php ENDPATH**/ ?>