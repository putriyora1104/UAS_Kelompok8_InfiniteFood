
<?php $__env->startSection('pageTitle','Home'); ?>
<?php $__env->startSection('content'); ?>

<div class="container-fluid" >
    <div class="row">
        <div class="col-lg-12 landing-header">
            <div class="landing-text col-sm-6">
                <h1>Infinite Food</h1>
                <span>Daftar makanan tradisional khas Banyumas</span>
            </div>
        </div>
    </div>
</div>

<div class="container mt-3">

    <div class="row">
        <div class="col-lg-sm">
            <h3>Food List</h3>
            <span class>
                Daftar Makanan di Banyumas
            </span>
        </div>
    </div>

    <div class="row mt-4">

    <?php if($Food->isEmpty()): ?>
        <p class="text-center text-danger">Data Tidak Ada</p>
    <?php endif; ?>
    <?php $__currentLoopData = $Food; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $f): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="col-sm-4 mt-4">
            <div class="card">
                <img src="<?php echo e(URL::to('/'), false); ?>/uploads/<?php echo e($f['food_photo'], false); ?>" class="card-img-top" alt="HelPic">
                <div class="card-body">
                    <div class="card-title"><?php echo e($f['food_name'], false); ?></div>
                    <div class="card-subtitle mb-2 text-muted">
                        <span><?php echo e($f['category']->categoryName, false); ?></span>
                        <span>•</span>
                        <span>
                            <?php for($i=0;$i<$f['food_price'];$i++): ?>
                                $
                            <?php endfor; ?>
                        </span>
                    </div>

                    
                    <p class="card-text food-description"><?php echo e($f['food_description'], false); ?></p>
                    <a href="<?php echo e(route('food.viewFood',['id'=>$f->id]), false); ?>" class="card-link">Lihat lebih lengkap</a>
                </div>
            </div>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


    </div>
    <div class="row mt-4">
         <div class="col-lg-12">
             <div class="d-flex justify-content-center">
                <nav aria-label="Page navigation example">
                    <ul class="pagination justify-content-end">
                        <li class="page-item <?php echo e($Food->currentPage()==1?'disabled':'', false); ?>">
                        <a class="page-link" href="<?php echo e($Food->previousPageUrl(), false); ?>" tabindex="-1">Previous</a>
                        </li>
                        <?php for($i=($Food->currentPage());$i<$Food->currentPage()+3;$i++): ?>
                            <li class="page-item <?php echo e($Food->currentPage()==$i?'disabled':'', false); ?>"><a class="page-link" href="<?php echo e($Food->url($i), false); ?>"><?php echo e($i, false); ?></a></li>
                        <?php endfor; ?>

                        <li class="page-item <?php echo e($Food->currentPage()==$Food->lastPage()?'disabled':'', false); ?>">
                        <a class="page-link" href="<?php echo e($Food->nextPageUrl(), false); ?>">Next</a>
                        </li>
                    </ul>
                </nav>
                </div>
         </div>
    </div>
</div>

<?php 
?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('template.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\Laravel\InfiniteFood\resources\views/home.blade.php ENDPATH**/ ?>