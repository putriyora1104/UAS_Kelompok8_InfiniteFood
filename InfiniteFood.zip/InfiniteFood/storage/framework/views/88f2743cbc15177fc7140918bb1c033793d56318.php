<!DOCTYPE html>
<!--[if lt IE 7]>      
<html class="no-js lt-ie9 lt-ie8 lt-ie7">
   <![endif]-->
   <!--[if IE 7]>         
   <html class="no-js lt-ie9 lt-ie8">
      <![endif]-->
      <!--[if IE 8]>         
      <html class="no-js lt-ie9">
         <![endif]-->
         <!--[if gt IE 8]>      
         <html class="no-js">
            <!--<![endif]-->
            <html>
               <head>
                  <meta charset="utf-8">
                  <meta http-equiv="X-UA-Compatible" content="IE=edge">
                  <title>Infinite Food - Login</title>
                  <meta name="description" content="">
                  <meta name="viewport" content="width=device-width, initial-scale=1">
                  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-giJF6kkoqNQ00vy+HMDP7azOuL0xtbfIcaT9wjKHr8RbDVddVHyTfAAsrekwKmP1" crossorigin="anonymous">
                  <link rel="icon" href="<?php echo e(url('/assets/image/infinite-food-ico.png'), false); ?>"/>
                  <link rel="stylesheet" href="<?php echo e(asset('css/login.css'), false); ?>">
               </head>
               <body >

                  

                  
                  <!--[if lt IE 7]>
                  <p class="browsehappy">You are using an <strong>outdated</strong> browser. Please <a href="#">upgrade your browser</a> to improve your experience.</p>
                  <![endif]-->

                  
                  
                  <form class="form-signin" method="post" action="<?php echo e(url('/admin/checkLogin'), false); ?>">
                     <?php if($message = Session::get('error')): ?>
                      <div class="alert alert-danger" role="alert">
                                             <?php echo e($message, false); ?>


                     </div>

                     <?php endif; ?>
                     <?php echo e(csrf_field(), false); ?>


                     <div class="text-center mb-4">
                        <img class="mb-4" src="<?php echo e(url('/assets/image/logo_utama.png'), false); ?>" alt="" height="32">
                     </div>
                     <div class="form-label-group">
                        <input type="email" name="email" id="inputEmail" class="form-control" placeholder="Username" required autofocus>
                        <label for="inputEmail">Username</label>
                     </div>
                     <div class="form-label-group">
                        <input type="password" name="password" id="inputPassword" class="form-control" placeholder="Password" required>
                        <label for="inputPassword">Password</label>
                     </div>
                     <div class="checkbox mb-3">
                        <label>
                        <input type="checkbox" value="remember-me"> Remember me
                        </label>
                     </div>
                     <button class="btn btn-lg btn-primary btn-block" type="submit">Sign in</button>
                     <p class="mt-5 mb-3 text-muted text-center">&copy; 2017-2018</p>
                  </form>
                  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta1/dist/js/bootstrap.bundle.min.js" integrity="sha384-ygbV9kiqUc6oa4msXn9868pTtWMgiQaeYH7/t7LECLbyPA2x65Kgf80OJFdroafW" crossorigin="anonymous"></script>
               </body>
            </html><?php /**PATH F:\Laravel\InfiniteFood\resources\views/dashboard/login.blade.php ENDPATH**/ ?>