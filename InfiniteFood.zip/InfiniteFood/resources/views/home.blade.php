@extends('template.base')
@section('pageTitle','Home')
@section('content')

<div class="container-fluid" >
    <div class="row">
        <div class="col-lg-12 landing-header">
            <div class="landing-text col-sm-6">
                <h1>Infinite Food</h1>
                <span>Daftar makanan tradisional khas Banyumas</span>
            </div>
        </div>
    </div>
</div>

<div class="container mt-3">

    <div class="row">
        <div class="col-lg-sm">
            <h3>Food List</h3>
            <span class>
                Daftar Makanan di Banyumas
            </span>
        </div>
    </div>

    <div class="row mt-4">

    @if($Food->isEmpty())
        <p class="text-center text-danger">Data Tidak Ada</p>
    @endif
    @foreach($Food as $f)
        <div class="col-sm-4 mt-4">
            <div class="card">
                <img src="{{ URL::to('/') }}/uploads/{{$f['food_photo']}}" class="card-img-top" alt="HelPic">
                <div class="card-body">
                    <div class="card-title">{{$f['food_name']}}</div>
                    <div class="card-subtitle mb-2 text-muted">
                        <span>{{$f['category']->categoryName}}</span>
                        <span>•</span>
                        <span>
                            @for($i=0;$i<$f['food_price'];$i++)
                                $
                            @endfor
                        </span>
                    </div>

                    
                    <p class="card-text food-description">{{$f['food_description']}}</p>
                    <a href="{{route('food.viewFood',['id'=>$f->id])}}" class="card-link">Lihat lebih lengkap</a>
                </div>
            </div>
        </div>
    @endforeach


    </div>
    <div class="row mt-4">
         <div class="col-lg-12">
             <div class="d-flex justify-content-center">
                <nav aria-label="Page navigation example">
                    <ul class="pagination justify-content-end">
                        <li class="page-item {{$Food->currentPage()==1?'disabled':''}}">
                        <a class="page-link" href="{{$Food->previousPageUrl()}}" tabindex="-1">Previous</a>
                        </li>
                        @for($i=($Food->currentPage());$i<$Food->currentPage()+3;$i++)
                            <li class="page-item {{$Food->currentPage()==$i?'disabled':''}}"><a class="page-link" href="{{$Food->url($i)}}">{{$i}}</a></li>
                        @endfor

                        <li class="page-item {{$Food->currentPage()==$Food->lastPage()?'disabled':''}}">
                        <a class="page-link" href="{{$Food->nextPageUrl()}}">Next</a>
                        </li>
                    </ul>
                </nav>
                </div>
         </div>
    </div>
</div>

@php 
@endphp

@endsection