@extends('dashboard.template.base')
@section('content')

<div class="row mt-5">
    <div class="col-lg-6">

    <div class="card p-3">
        <div class="card-title"><h4>Add Food Data</h4></div>
        <div class="card-body">
            <form action="{{$Food->id!=null?'/dashboard/food/update/'.$Food->id:url('/dashboard/food/store')}}" enctype="multipart/form-data" method="POST">
                @csrf


                <div class="mb-3">
                    <label for="formFile" class="form-label">Food Photo</label>
                    <input class="form-control" type="file" name="food_photo" id="formFile">
                </div>


                <div class="mb-3">
                    <label for="food_name" name="food_name" class="form-label">Food Name</label>
                    <input type="text" class="form-control" name="food_name" id="food_name" placeholder="Mendoan" required {{$Food->id!=null?"value=$Food->food_name":""}} >
                </div>

                <div class="mb-3">
                    <label for="food_description" name="food_description" class="form-label">Food Description</label>
                    <textarea class="form-control" name="food_description" id="food_description" rows="3" required >{{$Food->id!=null?$Food->food_description:''}}</textarea>
                </div>


                <div class="mb-3">
                    <label for="food_category" name="food_category" class="form-label">Food Description</label>
                    <select class="form-select" name="food_category" aria-label="food_category" required>
                        @foreach($foodCategory as $fc)
                            @if($Food->id!=null && $Food->food_category == $fc['id'])
                                <option value="{{$fc['id']}} " selected>{{$fc['categoryName']}}</option>
                                @continue
                            @endif
                            <option value="{{$fc['id']}}">{{$fc['categoryName']}}</option>
                        @endforeach
                    </select>
                </div>

                <div class="mb-3">
                    <label for="food_price" name="food_price" class="form-label">Food Price Average</label>
                    <select class="form-select" name="food_price" aria-label="food_price">
                        @for($i=1;$i<=(5);$i++)
                            @if($Food->id!=null && $Food->food_price == $i)
                                <option value="{{$fc['id']}} " selected>{{$i}}</option>
                                @continue
                            @endif
                            <option value="{{$i}}">{{$i}}</option>
                        @endfor
                    </select>
                </div>

                <button type="submit" class="btn btn-primary">{{$Food->id!=null?'Save':'Submit'}}</button>

            </form>
        </div>
    </div>
    </div>
</div>



@endsection