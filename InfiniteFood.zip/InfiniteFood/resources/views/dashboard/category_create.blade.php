@extends('dashboard.template.base')
@section('content')

<div class="row mt-5">
    <div class="col-lg-6">

    <div class="card p-3">
        <div class="card-title"><h4>Add Category Data</h4></div>
        <div class="card-body">
            <form action="{{$FoodCategory->id!=null?'/dashboard/category/update/'.$FoodCategory->id:url('/dashboard/category/store')}}" method="POST">
                @csrf
                <div class="mb-3">
                    <label for="food_category" name="food_category" class="form-label">Food Category</label>
                    <input type="text" class="form-control" name="food_category" id="food_category" placeholder="Mendoan" required {{$FoodCategory->id!=null?"value=$FoodCategory->categoryName":""}} >
                </div>
                <button type="submit" class="btn btn-primary">{{$FoodCategory->id!=null?'Save':'Submit'}}</button>

            </form>
        </div>
    </div>
    </div>
</div>





@endsection