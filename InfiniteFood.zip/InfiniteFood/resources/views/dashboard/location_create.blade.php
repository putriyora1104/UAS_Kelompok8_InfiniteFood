@extends('dashboard.template.base')
@section('content')
<link rel="stylesheet" href="https://unpkg.com/leaflet@1.7.1/dist/leaflet.css" integrity="sha512-xodZBNTC5n17Xt2atTPuE1HxjVMSvLVW9ocqUKLsCC5CXdbqCmblAshOMAS6/keqq/sMZMZ19scR4PsZChSR7A==" crossorigin=""/>
<script src="https://unpkg.com/leaflet@1.7.1/dist/leaflet.js" integrity="sha512-XQoYMqMTK8LvdxXYG3nZ448hOEQiglfqkJs1NOQV44cWnUrBc8PkAOcXy20w0vlaXaVUearIOBhiXZ5V3ynxwA==" crossorigin=""></script>
<div class="row mt-5">
    <div class="col-lg-6">

    <div class="card p-3">
        <div class="card-title"><h4>Add Category Data</h4></div>
        <div class="card-body">
            <form action="{{$FoodLocation->id!=null?'/dashboard/location/update/'.$FoodLocation->id:url('/dashboard/location/store')}}" method="POST">
                @csrf

                

                <div class="mb-3">
                    <label for="location_name" name="location_name" class="form-label">Place Name</label>
                    <input type="text" class="form-control" name="location_name" id="location_name" placeholder="Waroeng Kopy" required {{$FoodLocation->id!=null?"value=$FoodLocation->location_name":""}} >
                </div>

                <div class="mb-3">
                    <label for="food_id" class="form-label">Foodlist Select</label>
                    <input class="form-control" list="datalistOptions" id="food_id" name="food_id" placeholder="Type to search...">
                    <datalist id="datalistOptions" name="food_id">
                        @foreach($Food as $f){
                            @if($FoodLocation->id!=null && $FoodLocation->food_id == $f['id'])
                                    <option value="{{$f['id']}}" selected>{{$f['food_name']}}</option>
                                @continue
                            @endif
                            <option value="{{$f['id']}}">{{$f['food_name']}}</option>
                        }
                        @endforeach
                    </datalist>
                </div>

                <div class="mb-3">
                    <label for="latitude" name="latitude" class="form-label">Location Lat</label>
                    <input type="text" class="form-control" name="latitude" id="latitude" placeholder="174,199291" required {{$FoodLocation->id!=null?"value=$FoodLocation->latitude":""}} >
                </div>

                
                <div class="mb-3">
                    <label for="longitude" name="longitude" class="form-label">Location Lng</label>
                    <input type="text" class="form-control" name="longitude" id="longitude" placeholder="-7,2333" required {{$FoodLocation->id!=null?"value=$FoodLocation->longitude":""}} >
                </div>

                <div class="mb-3">
                    <label for="maps"  class="form-label">Or Select via Map</label>
                </div>

                <div class="col-lg-12">
                    <div id="map" style="height:300px;margin-bottom:30px"></div>
                </div>
                <button type="submit" class="btn btn-primary">{{$FoodLocation->id!=null?'Save':'Submit'}}</button>

            </form>
        </div>
    </div>
    </div>
</div>

<script>
    var mymap = L.map('map').setView([-7.4244176,109.2300951], 11);
      L.tileLayer('https://api.maptiler.com/maps/hybrid/{z}/{x}/{y}@2x.jpg?key=sl5nNkAdG1bPatKbI8un', {
		maxZoom: 18,
		attribution: 'Map data &copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors, ' +
			'Imagery © <a href="https://www.maptiler.com/">MapTiler</a>',
		id: 'mapbox/streets-v11',
		tileSize: 512,
		zoomOffset: -1
    }).addTo(mymap);

    var theMarker = {};

    mymap.on('click',function(e){
        if (theMarker != undefined) {
              mymap.removeLayer(theMarker);
        };
        theMarker  = new L.marker(e.latlng).addTo(mymap);

        lat = e.latlng.lat;
        lon = e.latlng.lng;

        $('#latitude').val(lat)
        $('#longitude').val(lon)
    })
</script>

@php 
@endphp

@endsection