@extends('dashboard.template.base')
@section('pageTitle','Food Management')
@section('content')

<div class="row">
    <div class="col-lg-12 mt-5">
        @if(session()->has('message'))
        <div class="alert alert-success alert-dismissible fade show" role="alert">
                        <strong>Berhasil!</strong> {{session()->get('message')}}

            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
    @endif
        <div class="card">
            <div class="card-body">
            <a type="button" href="{{url('/dashboard/location/create')}}" class="btn btn-primary btn-sm" style="float:right">Tambah Data</a>


                <div class="table-responsive mt-5">
                    <table class="table table-stripped table-hover mx-auto w-auto data-table">
                        <thead>
                            <tr>
                                <th>ID</th>
                                <th>Food ID</th>
                                <th>Location Name</th>
                                <th>LAT</th>
                                <th>LNG</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection

@section('script')
<script>
    $('.data-table').DataTable({
        processing:true,
        serverSide:true,
        ajax:"{{url('/dashboard/location')}}",

        columns:[

            {
                data:"id",
                name:"id",
            },

            {
                data:"food_id",
                name:"food_id"
            },
            
            {
                data:"location_name",
                name:"location_name",
            },

            {
                data:"latitude",
                name:"latitude",
            },

            {
                data:"longitude",
                name:"longitude",
            },

            {
                data:"action",
                name:"action",
            },
        ]
    })
</script>
@endsection