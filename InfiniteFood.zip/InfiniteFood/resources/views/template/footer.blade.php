
<footer class="bg-dark mt-5" style="min-height:100px">
    <div class="container-fluid">
        <div class="container">
            <div class="row pt-2">
                <div class="col-sm-3  pt-2">
                    <img src="{{url('/assets/image/logo_utama.png')}}" height="20px" alt="footer-logo" />
                </div>
            </div>

            <div class="row pt-4">
                <div class="col-sm-3  pt-2">
                    <p style="color:#fff">Copyright 2021</p>
                </div>
            </div>
    </div>
    </div>
</footer>