<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\FoodController;
use App\Http\Controllers\Controller;
use App\Http\Controllers\FoodCategoryController;
use App\Http\Controllers\FoodLocationController;
/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', [FoodController::class, 'index'])->name('food.index');
Route::get('/food/{id}',[FoodController::class, 'viewFood'])->name('food.viewFood');
Route::redirect('/admin','/admin/login');
Route::get('/admin/login',[Controller::class, 'AdminLogin'])->name('dashboard.AdminLogin');
Route::post('/admin/checkLogin',[Controller::class, 'checkLogin']);
Route::get('/admin/successLogin',[Controller::class, 'successLogin']);
Route::get('/admin/logout',[Controller::class, 'logout']);
Route::get('/dashboard/food',[FoodController::class, 'data'])->name('dashboard.home');
Route::get('/dashboard/category',[FoodCategoryController::class, 'data'])->name('dashboard.category');
Route::get('/dashboard/location',[FoodLocationController::class, 'data'])->name('dashboard.location');
Route::get('/dashboard/food/create',[FoodController::class, 'create'])->name('dashboard.food_create');
Route::post('/dashboard/food/store',[FoodController::class, 'store'])->name('food.store');
Route::get('/dashboard/food/edit/{id}',[FoodController::class, 'edit'])->name('food.edit');
Route::post('/dashboard/food/update/{id}',[FoodController::class, 'update'])->name('food.update');
Route::get('/dashboard/food/delete/{id}',[FoodController::class, 'delete'])->name('food.delete');
Route::get('/dashboard/category/create',[FoodCategoryController::class, 'create'])->name('dashboard.category_create');
Route::post('/dashboard/category/store',[FoodCategoryController::class, 'store'])->name('foodcategory.store');
Route::post('/dashboard/category/update/{id}',[FoodCategoryController::class, 'update'])->name('foodcategory.update');
Route::get('/dashboard/category/delete/{id}',[FoodCategoryController::class, 'delete'])->name('foodcategory.delete');
Route::get('/dashboard/category/edit/{id}',[FoodCategoryController::class, 'edit'])->name('foodcategory.edit');

Route::get('/dashboard/location/edit/{id}',[FoodLocationController::class, 'edit'])->name('foodlocation.edit');
Route::post('/dashboard/location/update/{id}',[FoodLocationController::class, 'update'])->name('foodlocation.update');
Route::get('/dashboard/location/delete/{id}',[FoodLocationController::class, 'delete'])->name('foodlocation.delete');
Route::get('/dashboard/location/create/',[FoodLocationController::class, 'create'])->name('foodlocation.create');
Route::post('/dashboard/location/store/',[FoodLocationController::class, 'store'])->name('foodlocation.store');
Route::get('image-upload', 'ImageUploadController@imageUpload')->name('image.upload');
Route::get('/dashboard/food/Upload-photo',[FoodController::class, 'upload'])->name('food.upload');


