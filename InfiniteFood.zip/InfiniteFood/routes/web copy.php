<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\FoodController;
use App\Http\Controllers\Controller;
use App\Http\Controllers\FoodCategoryController;
/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', [FoodController::class, 'index'])->name('food.index');
Route::get('/food/{id}',[FoodController::class, 'viewFood'])->name('food.viewFood');
Route::redirect('/admin','/admin/login');
Route::get('/admin/login',[Controller::class, 'AdminLogin'])->name('dashboard.AdminLogin');
Route::post('/admin/checkLogin',[Controller::class, 'checkLogin']);
Route::get('/admin/successLogin',[Controller::class, 'successLogin']);
Route::get('/admin/logout',[Controller::class, 'logout']);
Route::get('/dashboard/food',[FoodController::class, 'data'])->name('dashboard.home');
Route::get('/dashboard/category',[FoodCategoryController::class, 'data'])->name('dashboard.category');