<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\FoodCategory;
use App\Models\Food;
use DataTables;

class FoodCategoryController extends Controller
{
    public function index(){
        $data['FoodCategory'] = FoodCategory::all();
        return view('home',$data);
    }

    public function category(){
        return $this->belongsTo(FoodCategory::class,'food_category');
    }

    public function data(Request $r){
        if($r->ajax()){
            $data= FoodCategory::all();

            return DataTables::of($data)
                ->addIndexColumn()
                ->addColumn('action',function($row){
                    $btn = '
                    <div class="text-center">
                        <div class="btn-group">
                            <a href="'.route('foodcategory.edit',['id' => $row->id]).'">Edit</a> | 
                            <a href="'.route('foodcategory.delete',['id' => $row->id]).'">Hapus</a>
                        </div>
                    </div>
                    ';

                    return $btn;
                })
                ->rawColumns(['action'])
                ->make(true);
        }
        
        return view('dashboard.category');
    }


    public function create(){

        $data['FoodCategory'] = new FoodCategory();
        return view('dashboard.category_create',$data);
    }

    public function edit($id){

        $data['FoodCategory'] = FoodCategory::find($id);

        return view('dashboard.category_create',$data);
    }

    public function store(Request $r){
        $fc = new FoodCategory();
        $fc->categoryName = $r->food_category;
        $fc->save();
        return redirect(route('dashboard.category'))->with('message','Data berhasil disimpan');

    }


    public function update(Request $r,$id){
        $fc = FoodCategory::find($id);
        $fc->categoryName = $r->food_category;
        $fc->save();
        return redirect(route('dashboard.category'))->with('message','Data berhasil diubah!');

    }

    public function delete($id){
        $fc = FoodCategory::find($id);
        $fc->delete();
        return redirect(route('dashboard.category'))->with('message','Data berhasil dihapus!');

    }
    
}
