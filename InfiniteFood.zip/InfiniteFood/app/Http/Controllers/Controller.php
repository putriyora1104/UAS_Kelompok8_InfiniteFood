<?php

namespace App\Http\Controllers;
use Hash;
use Illuminate\Foundation\Auth\Access\AuthorizesRequests;
use Illuminate\Foundation\Bus\DispatchesJobs;
use Illuminate\Foundation\Validation\ValidatesRequests;
use Illuminate\Routing\Controller as BaseController;
use Validator;
use Auth;
use Illuminate\Http\Request;

class Controller extends BaseController
{
    use AuthorizesRequests, DispatchesJobs, ValidatesRequests;

    public function AdminLogin(){
        return view('dashboard.login');
    }

    function checkLogin(Request $r){
        
        $this->validate($r, [
            'email' => 'required|email',
            'password' => 'required|alphaNum|min:3'
        ]);

        $userData = array(
            'email' => $r->get('email'),
            'password' => $r->get('password'),
        );

        if(Auth::attempt($userData)){
            return redirect('admin/successLogin');
        }else{
            return back()->with('error','Username atau password salah !');
        }

    }


    function successLogin(){
        return view('dashboard.home');
    }

    function logout(){
        Auth::logout();
        return redirect('/admin');
    }
}


