<?php

namespace App\Http\Controllers;
use Hash;
use Illuminate\Http\Request;
use App\Models\Food;
use App\Models\FoodLocation;
use App\Models\FoodCategory;
use DataTables;
class FoodController extends Controller
{
    public function index(){
        $data['Food'] = Food::with('category')->paginate(1);
        $data['Faad'] = Hash::make('123');
        return view('home',$data);
    }

    public function viewFood($id){
        $data['Food'] = Food::with('locations')->find($id);

        return view('viewFood',$data);
    }

    public function data(Request $r){
        
        if($r->ajax()){
            $data= Food::with('category')->get();

            return DataTables::of($data)
                ->addIndexColumn()
                ->addColumn('action',function($row){
                    $btn = '
                    <div class="text-center">
                        <div class="btn-group">
                            <a href="'.route('food.edit',['id' => $row->id]).'">Edit</a> | 
                            <a href="'.route('food.delete',['id' => $row->id]).'">Hapus</a>
                        </div>
                    </div>
                    ';

                    return $btn;
                })
                ->rawColumns(['action'])
                ->make(true);
        }
        
        return view('dashboard.home');

    }

    public function create(){

        $data['foodCategory'] = FoodCategory::all();
        $data['Food'] = new Food();
        return view('dashboard.food_create',$data);
    }

    public function store(Request $r){
        $food = new Food();


        if ($r->hasFile('food_photo')) {
            $image = $r->file('food_photo');
            $photoname = time().'.'.$image->getClientOriginalExtension();
            $destinationPath = public_path('/uploads');
            $image->move($destinationPath, $photoname);
        }else{
            $photoname = $food->food_photo;
        }
        $food->food_name = $r->food_name;
        $food->food_category = $r->food_category;
        $food->food_price = $r->food_price;
        $food->food_description = $r->food_description;
        $food->food_photo = $photoname;

        $food->save();
        return redirect(route('dashboard.home'))->with('message','Data berhasil disimpan');
    }

    public function update(Request $r,$id){
        
        
        $food = Food::find($id);

        if ($r->hasFile('food_photo')) {
            $image = $r->file('food_photo');
            $photoname = time().'.'.$image->getClientOriginalExtension();
            $destinationPath = public_path('/uploads');
            $image->move($destinationPath, $photoname);
        }else{
            $photoname = $food->food_photo;
        }

        $food->food_name = $r->food_name;
        $food->food_category = $r->food_category;
        $food->food_price = $r->food_price;
        $food->food_description = $r->food_description;
        $food->food_photo = $photoname;

        $food->save();
        return redirect(route('dashboard.home'))->with('message','Data berhasil disimpan');
    }

    public function edit($id){

        $data['Food'] = Food::find($id);
        $data['foodCategory'] = FoodCategory::all();

        return view('dashboard.food_create',$data);
    }

    public function delete($id){
        $Food = Food::find($id);
        $Food->delete();

        return redirect(route('dashboard.home'))->with('message',"data berhasil ditambahkan!");
    }

    public function upload(Request $r){
         $request->validate([
            'image' => 'required|image|mimes:jpeg,png,jpg,gif,svg|max:2048',
        ]);
  
        $imageName = time().'.'.$request->image->extension();  
   
        $request->image->move(public_path('assets/upload'), $imageName);
   
        return back()
            ->with('success','You have successfully upload image.')
            ->with('image',$imageName);
    }

    



}
    

