<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\FoodLocation;
use App\Models\Food;

use DataTables;

class FoodLocationController extends Controller
{
    public function byID($id){
        $data['FoodLocation'] = FoodLocation::where('food_id', '=', '$id')->firstOrFail();
        return $data;
    }

    public function data(Request $r){
        if($r->ajax()){
            $data= FoodLocation::all();

            return DataTables::of($data)
                ->addIndexColumn()
                ->addColumn('action',function($row){
                    $btn = '
                    <div class="text-center">
                        <div class="btn-group">
                            <a href="'.route('foodlocation.edit',['id' => $row->id]).'">Edit</a> | 
                            <a href="'.route('foodlocation.delete',['id' => $row->id]).'">Hapus</a>
                        </div>
                    </div>
                    ';

                    return $btn;
                })
                ->rawColumns(['action'])
                ->make(true);
        }
        
        return view('dashboard.location');
    }


    public function create(){

        $data['FoodLocation'] = new FoodLocation();
        $data['Food'] = Food::all();
        return view('dashboard.location_create',$data);
    }


    public function store(Request $r){
        $fc = new FoodLocation();
        $fc->location_name = $r->location_name;
        $fc->latitude = $r->latitude;
        $fc->longitude = $r->longitude;
        $fc->food_id = $r->food_id;
        $fc->save();
        return redirect(route('dashboard.location'))->with('message','Data berhasil disimpan');

    }

    public function edit($id){

        $data['FoodLocation'] = FoodLocation::find($id);
        $data['Food'] = Food::all();
        return view('dashboard.location_create',$data);
    }


    public function update(Request $r,$id){

        $fc = FoodLocation::find($id);
        $fc->location_name = $r->location_name;
        $fc->latitude = $r->latitude;
        $fc->longitude = $r->longitude;
        $fc->food_id = $r->food_id;
        $fc->save();
        return redirect(route('dashboard.location'))->with('message','Data berhasil diupdate!');

    }


    public function delete($id){
        $fc = FoodLocation::find($id);
        $fc->delete();
        return redirect(route('dashboard.location'))->with('message','Data berhasil dihapus!');

    }
    
}
