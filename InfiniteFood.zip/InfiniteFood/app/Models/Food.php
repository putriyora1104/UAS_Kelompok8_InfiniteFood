<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Food extends Model
{
    use HasFactory;
    
    public function category(){
        return $this->belongsTo(FoodCategory::class,'food_category');
    }

    public function locations(){
        return $this->hasMany(FoodLocation::class,'food_id','id');
    }

}
